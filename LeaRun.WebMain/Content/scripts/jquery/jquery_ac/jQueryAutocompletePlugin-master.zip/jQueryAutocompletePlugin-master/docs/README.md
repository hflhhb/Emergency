#ABOUT THIS DOCUMENTATION:#
Please note that the documentation in these folders are lifted straight off of [the jQuery docs site](http://docs.jquery.com "Plugins/Autocomplete - jQuery JavaScript Library") after learning that they would eventually be shut down. I made sure that all the basic information is here, and navigation between the Plugin pages work. Links to other areas in the jQuery docs site (outside of the Autocomplete Plugin realm) do not work.

--AGA